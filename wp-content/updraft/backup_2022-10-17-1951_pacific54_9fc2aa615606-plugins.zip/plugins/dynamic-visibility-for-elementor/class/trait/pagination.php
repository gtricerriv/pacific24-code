<?php
namespace DynamicVisibilityForElementor;

use DynamicVisibilityForElementor\Plugin;

trait Pagination {

	
}
