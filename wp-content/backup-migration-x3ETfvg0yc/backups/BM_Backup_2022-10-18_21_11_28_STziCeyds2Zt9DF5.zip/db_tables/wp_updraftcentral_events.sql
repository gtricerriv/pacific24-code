/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_updraftcentral_events`; */
/* PRE_TABLE_NAME: `1666127488_wp_updraftcentral_events`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_updraftcentral_events` ( `event_id` bigint(20) NOT NULL AUTO_INCREMENT, `time` int(11) NOT NULL, `site_id` bigint(20) NOT NULL, `event_type` text COLLATE utf8mb4_unicode_ci NOT NULL, `event_name` text COLLATE utf8mb4_unicode_ci NOT NULL, `event_data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL, `event_status` text COLLATE utf8mb4_unicode_ci NOT NULL, `event_result_data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL, PRIMARY KEY (`event_id`), KEY `site_id` (`site_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
