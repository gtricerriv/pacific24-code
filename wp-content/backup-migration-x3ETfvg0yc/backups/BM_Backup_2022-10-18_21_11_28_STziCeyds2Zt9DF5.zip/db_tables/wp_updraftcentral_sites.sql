/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_updraftcentral_sites`; */
/* PRE_TABLE_NAME: `1666127488_wp_updraftcentral_sites`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_updraftcentral_sites` ( `site_id` bigint(20) NOT NULL AUTO_INCREMENT, `user_id` bigint(20) NOT NULL, `url` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL, `admin_url` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `key_local_private` blob DEFAULT NULL, `key_remote_public` blob DEFAULT NULL, `key_name_indicator` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL, `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL, `sequence_id` bigint(20) DEFAULT 0, `remote_user_id` bigint(20) NOT NULL, `remote_user_login` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `remote_site_id` bigint(20) DEFAULT 0, `connection_method` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `send_cors_headers` tinyint(1) DEFAULT 1, PRIMARY KEY (`site_id`), KEY `user_id` (`user_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
