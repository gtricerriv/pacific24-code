/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_mailpoet_user_flags`; */
/* PRE_TABLE_NAME: `1666127488_wp_mailpoet_user_flags`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_mailpoet_user_flags` ( `id` int(11) unsigned NOT NULL AUTO_INCREMENT, `user_id` bigint(20) NOT NULL, `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `created_at` timestamp NULL DEFAULT NULL, `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), PRIMARY KEY (`id`), UNIQUE KEY `user_id_name` (`user_id`,`name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
