/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_mailpoet_subscriber_ips`; */
/* PRE_TABLE_NAME: `1666127488_wp_mailpoet_subscriber_ips`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_mailpoet_subscriber_ips` ( `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL, `created_at` timestamp NOT NULL DEFAULT current_timestamp(), PRIMARY KEY (`created_at`,`ip`), KEY `ip` (`ip`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
