/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_updraftcentral_site_temporary_keys`; */
/* PRE_TABLE_NAME: `1666127488_wp_updraftcentral_site_temporary_keys`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_updraftcentral_site_temporary_keys` ( `key_id` bigint(20) NOT NULL AUTO_INCREMENT, `key_local_private` blob DEFAULT NULL, `key_remote_public` blob DEFAULT NULL, `created` bigint(20) DEFAULT NULL, PRIMARY KEY (`key_id`), KEY `created` (`created`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
