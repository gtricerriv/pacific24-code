/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_mailpoet_custom_fields`; */
/* PRE_TABLE_NAME: `1666127488_wp_mailpoet_custom_fields`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_mailpoet_custom_fields` ( `id` int(11) unsigned NOT NULL AUTO_INCREMENT, `name` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL, `type` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL, `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL, `created_at` timestamp NULL DEFAULT NULL, `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), PRIMARY KEY (`id`), UNIQUE KEY `name` (`name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
