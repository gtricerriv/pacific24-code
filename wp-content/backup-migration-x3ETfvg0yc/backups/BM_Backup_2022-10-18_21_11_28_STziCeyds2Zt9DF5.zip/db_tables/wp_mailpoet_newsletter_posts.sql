/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_mailpoet_newsletter_posts`; */
/* PRE_TABLE_NAME: `1666127488_wp_mailpoet_newsletter_posts`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_mailpoet_newsletter_posts` ( `id` int(11) unsigned NOT NULL AUTO_INCREMENT, `newsletter_id` int(11) unsigned NOT NULL, `post_id` int(11) unsigned NOT NULL, `created_at` timestamp NULL DEFAULT NULL, `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), PRIMARY KEY (`id`), KEY `newsletter_id` (`newsletter_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
