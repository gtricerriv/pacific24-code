/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_updraftcentral_sitemeta`; */
/* PRE_TABLE_NAME: `1666127488_wp_updraftcentral_sitemeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_updraftcentral_sitemeta` ( `meta_id` bigint(20) NOT NULL AUTO_INCREMENT, `site_id` bigint(20) NOT NULL DEFAULT 0, `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL, `created` bigint(20) DEFAULT 0, PRIMARY KEY (`meta_id`), KEY `meta_key` (`meta_key`(191)), KEY `site_id` (`site_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
