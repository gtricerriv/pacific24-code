/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_mailpoet_user_agents`; */
/* PRE_TABLE_NAME: `1666127488_wp_mailpoet_user_agents`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_mailpoet_user_agents` ( `id` int(11) unsigned NOT NULL AUTO_INCREMENT, `hash` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL, `user_agent` text COLLATE utf8mb4_unicode_ci NOT NULL, `created_at` timestamp NULL DEFAULT NULL, `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), PRIMARY KEY (`id`), UNIQUE KEY `hash` (`hash`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
