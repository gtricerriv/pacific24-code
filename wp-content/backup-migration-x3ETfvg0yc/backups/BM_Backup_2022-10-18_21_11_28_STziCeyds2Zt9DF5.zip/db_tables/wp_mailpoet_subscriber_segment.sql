/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_mailpoet_subscriber_segment`; */
/* PRE_TABLE_NAME: `1666127488_wp_mailpoet_subscriber_segment`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_mailpoet_subscriber_segment` ( `id` int(11) unsigned NOT NULL AUTO_INCREMENT, `subscriber_id` int(11) unsigned NOT NULL, `segment_id` int(11) unsigned NOT NULL, `status` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'subscribed', `created_at` timestamp NULL DEFAULT NULL, `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), PRIMARY KEY (`id`), UNIQUE KEY `subscriber_segment` (`subscriber_id`,`segment_id`), KEY `segment_id` (`segment_id`)) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1666127488_wp_mailpoet_subscriber_segment` (`id`, `subscriber_id`, `segment_id`, `status`, `created_at`, `updated_at`) VALUES (1,1,1,'subscribed','2022-10-17 17:24:44','2022-10-17 17:24:44');
