/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_updraftcentral_user_cron`; */
/* PRE_TABLE_NAME: `1666127488_wp_updraftcentral_user_cron`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666127488_wp_updraftcentral_user_cron` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `user_id` bigint(20) NOT NULL, `last_run` bigint(20) DEFAULT 0, PRIMARY KEY (`id`), KEY `user_id` (`user_id`), KEY `last_run` (`last_run`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1666127488_wp_updraftcentral_user_cron` (`id`, `user_id`, `last_run`) VALUES (1,1,1665949738);
